function AddUserPageAccess()
{
	let DataArr = {Access:1,page:document.querySelector("[name=pid]").value,user:document.querySelector("[name=uid]").value,lvl:document.querySelector("[name=aid]").value};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddUserPAgeAccess.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddAccess()
{
	let page_id = document.querySelector("[id=access_pageid_tbl]").value;
	let user_id = document.querySelector("[id=access_userid_tbl]").value;
	let DataArr = {Access:1,page_id:page_id,user_id:user_id};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddAccess.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddPage()
{
	let page_id = document.querySelector("[id=pageid_tbl]").value;
	let page_name = document.querySelector("[id=pagename_tbl]").value;
	let page_url = document.querySelector("[id=pageurl_tbl]").value;
	let page_lvl = document.querySelector("[id=pagelvl_tbl]").value;
	let DataArr = {Access:1,page:page_name,path:page_url,pid:page_id,lvl:page_lvl};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddPage.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteAccess()
{	

	let strid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,strid:strid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteAccess.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeletePage()
{
	let pageid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,pageid:pageid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeletePage.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteCommandAccess()
{
	let commandid = document.activeElement.parentElement.parentElement.children[2].innerText;
	let pageid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,commandid:commandid,pageid:pageid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteCommandAccess.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteCommand()
{
	let commandid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,commandid:commandid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteCommand.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeletePost()
{
	let postdid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,postdid:postdid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeletePost.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteGroup()
{
	let groupid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,groupid:groupid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteGroup.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteStatus()
{
	let statusid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,statusid:statusid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteStatus.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteDivisions()
{
	let divisionid = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,divisionid:divisionid};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteDivision.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddCommand()
{
	let commandid = document.querySelector("[name=idcommand]").value;
	let commandname = document.querySelector("[name=commandname]").value;
	let commandurl = document.querySelector("[name=commandpath]").value;
	let DataArr = {Access:1,commandid:commandid,commandname:commandname,commandurl:commandurl};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddCommand.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddCommandPageAccess()
{
	let commandid = document.querySelector("[name=idpageCMD]").value;
	let pageid = document.querySelector("[name=idcommandCMD]").value;
	let lvl = document.querySelector("[name=lvlCMD]").value;
	let DataArr = {Access:1,commandid:commandid,pageid:pageid,lvl:lvl};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddCommandPageAccess.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddDivision()
{
	let divid = document.querySelector("[name=divid]").value;
	let divname = document.querySelector("[name=divname]").value;
	let divbrif = document.querySelector("[name=divbrif]").value;
	let DataArr = {Access:1,divid:divid,divname:divname,divbrif:divbrif};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddDivision.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddStatus()
{
	let statid = document.querySelector("[name=statid]").value;
	let statname = document.querySelector("[name=statname]").value;
	let DataArr = {Access:1,statid:statid,statname:statname};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddStatus.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddGroup()
{
	let grid = document.querySelector("[name=grid]").value;
	let grname = document.querySelector("[name=grname]").value;
	let DataArr = {Access:1,grid:grid,grname:grname};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddGroup.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddPost()
{
	let posid = document.querySelector("[name=posid]").value;
	let posname = document.querySelector("[name=posname]").value;
	let DataArr = {Access:1,posid:posid,posname:posname};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddPost.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddUser()
{
	let fname = document.querySelector("[name=fname]").innerText;
	let lname = document.querySelector("[name=lname]").innerText;
	let pname = document.querySelector("[name=pname]").innerText;
	let postl = document.querySelector('[name=postl]').options[document.querySelector('[name=postl]').options.selectedIndex].value
	let statusl = document.querySelector('[name=statusl]').options[document.querySelector('[name=statusl]').options.selectedIndex].value
	let divisionl = document.querySelector('[name=divisionl]').options[document.querySelector('[name=divisionl]').options.selectedIndex].value
	let groupl = document.querySelector('[name=groupl]').options[document.querySelector('[name=groupl]').options.selectedIndex].value
	let logn = document.querySelector("[name=logn]").innerText;
	let pswrd = document.querySelector("[name=pswrd]").innerText;
	
	let srtcname = '';
	let DataArr = '';
	if (logn == '' || pswrd == '') 
	{
		srtcname = "AddUser.php";
		DataArr = {Access:1,fname:fname,lname:lname,pname:pname,postl:postl,statusl:statusl,divisionl:divisionl,groupl:groupl};
	}
	else
	{
		srtcname = "AddUserAuth.php";
		DataArr = {Access:1,fname:fname,lname:lname,pname:pname,postl:postl,statusl:statusl,divisionl:divisionl,groupl:groupl,logn:logn,pswrd:pswrd};
	}
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/"+srtcname,
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteUserAuth()
{
	let iduser = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,iduser:iduser};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteUserAuth.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function DeleteUser()
{
	let iduser = document.activeElement.parentElement.parentElement.children[0].innerText;
	let DataArr = {Access:1,iduser:iduser};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/DeleteUser.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function AddUserLogPass()
{
	let iduser = document.activeElement.parentElement.parentElement.children[0].innerText;
	let passuser = document.activeElement.parentElement.parentElement.children[9].innerText;
	let loguser = document.activeElement.parentElement.parentElement.children[8].innerText;
	let DataArr = {Access:1,iduser:iduser,passuser:passuser,loguser:loguser};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/AddUserLogPass.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}
function ChangeUserAuth()
{
	let iduser = document.activeElement.parentElement.parentElement.children[0].innerText;
	let passuser = document.activeElement.parentElement.parentElement.children[9].innerText;
	let loguser = document.activeElement.parentElement.parentElement.children[8].innerText;
	if (passuser == '***') 
	{
		return;
	}
	let DataArr = {Access:1,iduser:iduser,passuser:passuser,loguser:loguser};
	$.ajax({
		async:false,
		type: "POST",
	    url: "ESCR/ChangeUserAuth.php",
	    dataType: 'json',
	    data: DataArr,
	    success: function(data)
	    {
	    	location.reload();
	    },
	    error: function(jqXHR, status, e) 
	    {
	        if (status === "timeout") 
	        {  
	            alert("Время ожидания ответа истекло!");
	        } 
	        else 
	        {
	            //alert(status); // Другая ошибка
	            alert('Сервер не смог обработать запрос. Попробуйте снова или обратитесь на ИВЦ \n'+status+'\n'+e);
	            //alert(status);
	            //alert(e);
	        }	
	    }
	});
}