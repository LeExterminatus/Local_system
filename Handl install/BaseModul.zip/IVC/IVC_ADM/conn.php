<?php
class ControlDBConnectPG
{
	private static $db = null;
	public $Server;
	public $Database;
	public $UID;
	public $PWD;
	public $port;
	public $conn;

	public function __construct()
	{
		$rootPath = $_SERVER['DOCUMENT_ROOT'];
		$ini_array = parse_ini_file($rootPath."/IVC/conf.ini");
		$this->Server = $ini_array['Server'];
		$this->Database = $ini_array['Database'];
		$this->UID = $ini_array['UID'];
		$this->PWD = $ini_array['PWD'];
		$this->port = $ini_array['port'];
		try 
		{
			$this->conn = new PDO('pgsql:host='.$this->Server.';port='.$this->port.';dbname='.$this->Database.';', ''.$this->UID.'', ''.$this->PWD.'',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch (PDOException $e)
		{
			die($e->getMessage());
		}
	}
	public static function GetDB() 
	{
    	if (self::$db == null) self::$db = new ControlDBConnectPG();
    	return self::$db;
  	}
  	public function GetConn()
  	{
  		return $this->conn;
  	}
}
?>