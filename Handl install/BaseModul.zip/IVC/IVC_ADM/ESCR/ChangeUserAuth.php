<?php
header('content-type: application/json');
require_once("../conn.php");
if ($_POST['Access'] == 1) 
{
	$DBConnect = ControlDBConnectPG::GetDb();
	$QueryStr = "UPDATE authorizationinfo SET  
	password = '".password_hash($_POST['passuser'], PASSWORD_BCRYPT)."', login = '".$_POST['loguser']."'
	where iduser = '".$_POST['iduser']."'";
	$conn = $DBConnect->GetConn();
	$Query = $conn->prepare($QueryStr);
	$Query->execute();
	//$data = $Query->fetchAll(PDO::FETCH_ASSOC);

	echo json_encode('1');
}
else
{
	echo json_encode('У вас нет доступа!');
}
?>