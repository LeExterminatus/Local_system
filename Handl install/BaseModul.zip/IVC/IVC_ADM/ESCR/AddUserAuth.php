<?php
header('content-type: application/json');
require_once("../conn.php");
if ($_POST['Access'] == 1) 
{
	$DBConnect = ControlDBConnectPG::GetDb();
	$QueryStr = "INSERT INTO users(iduser,firstname,lastname,patronimic,post,status,division,user_group) VALUES (DEFAULT,'".$_POST['fname']."','".$_POST['lname']."','".$_POST['pname']."','".$_POST['postl']."','".$_POST['statusl']."','".$_POST['divisionl']."','".$_POST['groupl']."') RETURNING iduser";
	$conn = $DBConnect->GetConn();
	$Query = $conn->prepare($QueryStr);
	$Query->execute();
	$array = $Query->fetchAll(PDO::FETCH_ASSOC);

	$QueryStr = "INSERT INTO authorizationinfo VALUES ('".$array[0]['iduser']."','".password_hash($_POST['pswrd'], PASSWORD_BCRYPT)."','".$_POST['logn']."')";
	$conn = $DBConnect->GetConn();
	$Query = $conn->prepare($QueryStr);
	$Query->execute();
	//$data = $Query->fetchAll(PDO::FETCH_ASSOC);

	echo json_encode("Пользователь добавлен");
}
else
{
	echo json_encode('У вас нет доступа!');
}
?>