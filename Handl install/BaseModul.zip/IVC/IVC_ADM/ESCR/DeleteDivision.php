<?php
header('content-type: application/json');
require_once("../conn.php");
if ($_POST['Access'] == 1) 
{
	$DBConnect = ControlDBConnectPG::GetDb();
	$QueryStr = "DELETE FROM divisions WHERE iddivision='".$_POST['divisionid']."'";
	$conn = $DBConnect->GetConn();
	$Query = $conn->prepare($QueryStr);
	$Query->execute();
	//$data = $Query->fetchAll(PDO::FETCH_ASSOC);

	echo json_encode("");
}
else
{
	echo json_encode('У вас нет доступа!');
}
?>