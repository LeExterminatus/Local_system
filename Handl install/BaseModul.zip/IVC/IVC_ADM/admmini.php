<?php
echo "<script src='cntrl.js'></script>";
echo "<script src='/IVC/Ajax/Libs/JQuery/jquery-3.5.1.min.js'></script>";
echo "<link rel='stylesheet' type='text/css' href='stl.css'>";
require_once("conn.php");

$DBConnect = ControlDBConnectPG::GetDb();

$QueryStr = "SELECT * FROM Pagelist";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayD = $Query->fetchAll(PDO::FETCH_ASSOC);
echo "<table>";
	echo "<tr>";
		echo "<th>";
			echo "Ид страницы";
		echo "</th>";
		echo "<th>";
			echo "Название";
		echo "</th>";
		echo "<th>";
			echo "Адрес";
		echo "</th>";
		echo "<th>";
			echo "Уровень";
		echo "</th>";
	echo "</tr>";

	for ($i=0; $i < count($arrayD); $i++) 
	{ 
		echo "<tr>";
			echo "<td>";
				echo $arrayD[$i]['id'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['name'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['url'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['accesslevel'];
			echo "</td>";
			echo "<td>";
				echo "<button onclick='DeletePage()'>Удалить</button>";
				if ($arrayD[$i]['accesslevel'] == 2)
				{
					echo "<button onclick='CascadeDeletePage()' disabled>Удалить каскадно</button>";
				}
			echo "</td>";
		echo "</tr>";
	}
	echo "<tr>";
			echo "<td>";
				echo "<input type='text' id='pageid_tbl'>";
			echo "</td>";
			echo "<td>";
				echo "<input type='text' id='pagename_tbl'>";
			echo "</td>";
			echo "<td>";
				echo "<input type='text' id='pageurl_tbl'>";
			echo "</td>";
			echo "<td>";
				echo "<input type='text' id='pagelvl_tbl'>";
			echo "</td>";
			echo "<td>";
				echo "<button onclick='AddPage()'>Добавить</button>";
			echo "</td>";
		echo "</tr>";

echo "</table>";
echo "Список прав на страницы";
$QueryStr = "SELECT
			PA.id,
			U.iduser, U.lastname||' '||U.firstname||' '||U.patronimic AS fio,
			PL.id AS pageid, PL.name, PL.url
			FROM pageaccess AS PA
			LEFT JOIN users AS U ON U.iduser = PA.userid
			LEFT JOIN pagelist AS PL ON PL.id = PA.pageid";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayD = $Query->fetchAll(PDO::FETCH_ASSOC);

echo "<table>";
	echo "<tr>";
		echo "<th>";
			echo "Ид записи";
		echo "</th>";
		echo "<th>";
			echo "Ид страницы";
		echo "</th>";
		echo "<th>";
			echo "Название страницы";
		echo "</th>";
		echo "<th>";
			echo "Путь";
		echo "</th>";
		echo "<th>";
			echo "Ид юзера";
		echo "</th>";
		echo "<th>";
			echo "ФИО";
		echo "</th>";
	echo "</tr>";

	for ($i=0; $i < count($arrayD); $i++) 
	{ 
		echo "<tr>";
			echo "<td>";
				echo $arrayD[$i]['id'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['pageid'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['name'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['url'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['iduser'];
			echo "</td>";
			echo "<td>";
				echo $arrayD[$i]['fio'];
			echo "</td>";
			echo "<td>";
				echo "<button onclick='DeleteAccess()'>Удалить</button>";
			echo "</td>";
		echo "</tr>";
	}
	echo "<tr>";
		echo "<td colspan='7' style='background:black'>";
			
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td>";
			echo "Ид страницы";
		echo "</td>";
		echo "<td>";
			echo "Ид юзера";
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td>";
			echo "<input type='text' id='access_pageid_tbl'>";
		echo "</td>";
		echo "<td>";
			echo "<input type='text' id='access_userid_tbl'>";
		echo "</td>";
		echo "<td>";
			echo "<button onclick='AddAccess()'>Добавить</button>";
		echo "</td>";
	echo "</tr>";

echo "</table>";

echo "<HR>";
echo "Список групп, статусов, должностей и отделов";
$QueryStr = "SELECT * FROM Divisions";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayD = $Query->fetchAll(PDO::FETCH_ASSOC);
$QueryStr = "SELECT * FROM Status";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayS = $Query->fetchAll(PDO::FETCH_ASSOC);
$QueryStr = "SELECT * FROM Groups";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayG = $Query->fetchAll(PDO::FETCH_ASSOC);
$QueryStr = "SELECT * FROM Posts";
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$arrayP = $Query->fetchAll(PDO::FETCH_ASSOC);
echo "<div class='pageeditDV'>";
	echo "<div>";
		echo "<table>";
			echo "<tr>";
				echo "<th>";
					echo "ID";
				echo "</th>";
				echo "<th>";
					echo "Отдел";
				echo "</th>";
				echo "<th>";
					echo "Сокращенно";
				echo "</th>";
			echo "</tr>";
			for ($i=0; $i < count($arrayD); $i++) 
			{ 
				echo "<tr>";
					echo "<td>";
						echo $arrayD[$i]['iddivision'];
					echo "</td>";
					echo "<td>";
						echo $arrayD[$i]['description'];
					echo "</td>";
					echo "<td>";
						echo $arrayD[$i]['briefly'];
					echo "</td>";
					echo "<td>";
						echo "<button onclick='DeleteDivisions()'>Удалить</button>";
					echo "</td>";
				echo "</tr>";
			}
		echo "</table>";
		echo "<div>";
			echo "Добавить отдел";
			echo "<br>";
			echo "ID отдела <input type='text' name='divid'>";
			echo "<br>";
			echo "Название отдела <input type='text' name='divname'>";
			echo "<br>";
			echo "Сокращенно <input type='text' name='divbrif'>";
			echo "<br>";
			echo "<button onclick='AddDivision()'>Внести</button>";
			echo "<br>";
		echo "</div>";
	echo "</div>";
	echo "<div>";
		echo "<table>";
			echo "<tr>";
				echo "<th>";
					echo "ID";
				echo "</th>";
				echo "<th>";
					echo "Статус";
				echo "</th>";
			echo "</tr>";
			for ($i=0; $i < count($arrayS); $i++) 
			{ 
				echo "<tr>";
					echo "<td>";
						echo $arrayS[$i]['idstatus'];
					echo "</td>";
					echo "<td>";
						echo $arrayS[$i]['description'];
					echo "</td>";
					echo "<td>";
						echo "<button onclick='DeleteStatus()'>Удалить</button>";
					echo "</td>";
				echo "</tr>";
			}
		echo "</table>";
		echo "<div>";
			echo "Добавить статус";
			echo "<br>";
			echo "ID статуса <input type='text' name='statid'>";
			echo "<br>";
			echo "Название статуса <input type='text' name='statname'>";
			echo "<br>";
			echo "<button onclick='AddStatus()'>Внести</button>";
			echo "<br>";
		echo "</div>";
	echo "</div>";
	echo "<div>";
		echo "<table>";
			echo "<tr>";
				echo "<th>";
					echo "ID";
				echo "</th>";
				echo "<th>";
					echo "Группа";
				echo "</th>";
			echo "</tr>";
			for ($i=0; $i < count($arrayG); $i++) 
			{ 
				echo "<tr>";
					echo "<td>";
						echo $arrayG[$i]['idgroup'];
					echo "</td>";
					echo "<td>";
						echo $arrayG[$i]['description'];
					echo "</td>";
					echo "<td>";
						echo "<button onclick='DeleteGroup()'>Удалить</button>";
					echo "</td>";
				echo "</tr>";
			}
		echo "</table>";
		echo "<div>";
			echo "Добавить группу";
			echo "<br>";
			echo "ID группы <input type='text' name='grid'>";
			echo "<br>";
			echo "Название группы <input type='text' name='grname'>";
			echo "<br>";
			echo "<button onclick='AddGroup()'>Внести</button>";
			echo "<br>";
		echo "</div>";
	echo "</div>";
	echo "<div>";
		echo "<table>";
			echo "<tr>";
				echo "<th>";
					echo "ID";
				echo "</th>";
				echo "<th>";
					echo "Должность";
				echo "</th>";
			echo "</tr>";
			for ($i=0; $i < count($arrayP); $i++) 
			{ 
				echo "<tr>";
					echo "<td>";
						echo $arrayP[$i]['idpost'];
					echo "</td>";
					echo "<td>";
						echo $arrayP[$i]['description'];
					echo "</td>";
					echo "<td>";
						echo "<button onclick='DeletePost()'>Удалить</button>";
					echo "</td>";
				echo "</tr>";
			}
		echo "</table>";
		echo "<div>";
			echo "Добавить должность";
			echo "<br>";
			echo "ID должности <input type='text' name='posid'>";
			echo "<br>";
			echo "Название должности <input type='text' name='posname'>";
			echo "<br>";
			echo "<button onclick='AddPost()'>Внести</button>";
			echo "<br>";
		echo "</div>";
	echo "</div>";
echo "</div>";

echo "<HR>";
$QueryStr = "SELECT 
U.iduser, U.lastname, U.firstname, U.patronimic, 
AI.login, AI.password,
PST.description AS post, ST.description AS status, DV.description AS division,
GP.description AS group
FROM USERS AS U
LEFT JOIN POSTS AS PST ON PST.idpost = U.post
LEFT JOIN STATUS AS ST ON ST.idstatus = U.status
LEFT JOIN DIVISIONS AS DV ON DV.iddivision = U.division
LEFT JOIN GROUPS AS GP ON GP.idgroup = U.user_group
LEFT JOIN authorizationinfo AS AI ON AI.iduser = U.iduser";
//$DB = $this->DBConnect;
$conn = $DBConnect->GetConn();
$Query = $conn->prepare($QueryStr);
$Query->execute();
$array = $Query->fetchAll(PDO::FETCH_ASSOC);
echo "Список пользователей<br>";
echo "<table>";
echo "<tr>";
		echo "<th>";
			echo "ИД";
		echo "</th>";
		echo "<th>";
			echo "Фамилия";
		echo "</th>";
		echo "<th>";
			echo "Имя";
		echo "</th>";
		echo "<th>";
			echo "Отчество";
		echo "</th>";
		echo "<th>";
			echo "Должность";
		echo "</th>";
		echo "<th>";
			echo "Статус";
		echo "</th>";
		echo "<th>";
			echo "Подразделение";
		echo "</th>";
		echo "<th>";
			echo "Группа";
		echo "</th>";
		echo "<th>";
			echo "Логин";
		echo "</th>";
		echo "<th>";
			echo "Хэш/Пароль";
		echo "</th>";
echo "</tr>";
for ($i=0; $i < count($array); $i++) 
{ 
	echo "<tr>";
		echo "<td>";
			echo $array[$i]['iduser'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['lastname'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['firstname'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['patronimic'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['post'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['status'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['division'];
		echo "</td>";
		echo "<td>";
			echo $array[$i]['group'];
		echo "</td>";
		echo "<td contenteditable='true'>";
			echo $array[$i]['login'];
		echo "</td>";
		echo "<td contenteditable='true'>";
			//echo $array[$i]['password'];
			//echo "***";
			if (isset($array[$i]['password'])) 
			{
				echo "***";
			}
		echo "</td>";
		echo "<td>";
			echo "<button onclick='DeleteUser()'>Удалить</button>";
		echo "</td>";
		echo "<td>";
			if (isset($array[$i]['password'])) 
			{
				echo "<button onclick='DeleteUserAuth()'>Удалить лог\пас</button>";
				echo "<button onclick='ChangeUserAuth()'>Сменить лог\пас</button>";
			}
			else
			{
				echo "<button onclick='AddUserLogPass()'>Добавить лог\пас</button>";
			}
		echo "</td>";
	echo "</tr>";
}
echo "<tr>";
		echo "<td>";
			
		echo "</td>";
		echo "<td contenteditable='true' name='lname'>";
			
		echo "</td>";
		echo "<td contenteditable='true' name='fname'>";
			
		echo "</td>";
		echo "<td contenteditable='true' name='pname'>";
			
		echo "</td>";
		$QueryStr = "SELECT * FROM POSTS";
		$conn = $DBConnect->GetConn();
		$Query = $conn->prepare($QueryStr);
		$Query->execute();
		$array = $Query->fetchAll(PDO::FETCH_ASSOC);
		echo "<td>";
			echo "<select name='postl'>";
				echo "<option value=''>Не выбран</option>";
				for ($i=0; $i < count($array); $i++) 
				{ 
					echo "<option value='".$array[$i]['idpost']."'>".$array[$i]['description']."</option>";
				}
			echo "</select>";
		echo "</td>";
		$QueryStr = "SELECT * FROM STATUS";
		$conn = $DBConnect->GetConn();
		$Query = $conn->prepare($QueryStr);
		$Query->execute();
		$array = $Query->fetchAll(PDO::FETCH_ASSOC);
		echo "<td>";
			echo "<select name='statusl'>";
				echo "<option value=''>Не выбран</option>";
				for ($i=0; $i < count($array); $i++) 
				{ 
					echo "<option value='".$array[$i]['idstatus']."'>".$array[$i]['description']."</option>";
				}
			echo "</select>";
		echo "</td>";
		$QueryStr = "SELECT * FROM divisions";
		$conn = $DBConnect->GetConn();
		$Query = $conn->prepare($QueryStr);
		$Query->execute();
		$array = $Query->fetchAll(PDO::FETCH_ASSOC);
		echo "<td>";
			echo "<select name='divisionl'>";
				echo "<option value=''>Не выбран</option>";
				for ($i=0; $i < count($array); $i++) 
				{ 
					echo "<option value='".$array[$i]['iddivision']."'>".$array[$i]['description']."</option>";
				}
			echo "</select>";
		echo "</td>";
		$QueryStr = "SELECT * FROM groups";
		$conn = $DBConnect->GetConn();
		$Query = $conn->prepare($QueryStr);
		$Query->execute();
		$array = $Query->fetchAll(PDO::FETCH_ASSOC);
		echo "<td>";
			echo "<select name='groupl'>";
				echo "<option value=''>Не выбран</option>";
				for ($i=0; $i < count($array); $i++) 
				{ 
					echo "<option value='".$array[$i]['idgroup']."'>".$array[$i]['description']."</option>";
				}
			echo "</select>";
		echo "</td>";
		echo "<td contenteditable='true' name='logn'>";
			
		echo "</td>";
		echo "<td contenteditable='true' name='pswrd'>";
			
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
		echo "<td colspan='10'>";
			echo "<button onclick='AddUser()'>Внести</button>";
		echo "</td>";
	echo "</tr>";
echo "</table>";
?>