<?php
var_dump($_SERVER);
echo "<br>";
echo $_SERVER["SCRIPT_NAME"];
echo "<br>";
echo strripos($_SERVER["SCRIPT_NAME"],'/');
echo "<br>";
echo substr($_SERVER["SCRIPT_NAME"],0,strripos($_SERVER["SCRIPT_NAME"],'/'))."/index.php";
echo "<br>";
echo substr($_SERVER["SCRIPT_NAME"],0,strripos(substr($_SERVER["SCRIPT_NAME"],0,strripos($_SERVER["SCRIPT_NAME"],'/')),'/'))."/index.php";
?>