function ToggleMainMenu() 
{
	let LMenu = document.querySelector('.LeftMenu');
	let MainContainer = document.querySelector('.MainBody');

	if (MainContainer.classList.contains('FullWidth')) 
	{
		LMenu.classList.remove('hidden_elem');
		MainContainer.classList.remove('FullWidth');
	}
	else
	{
		LMenu.classList.add('hidden_elem');
		MainContainer.classList.add('FullWidth');
	}
}
function CustomAlert(type,text)
{
	const divElement = document.createElement('div');

	// Добавляем текст внутрь элемента
	divElement.textContent = text;

	// Добавляем класс стиля
	divElement.classList.add('castom_alert'); // Замените 'стиль' на имя нужного класса
	switch (type)
	{
		case 0:
			divElement.classList.add('positive_alert');
			break;
		case 1:
			divElement.classList.add('warning_alert');
			break;
		case 2:
			divElement.classList.add('negative_alert');
			break;
	}
	// Вставляем элемент в тело (body) документа
	document.body.appendChild(divElement);

	// Удаляем элемент через 10 секунд
	setTimeout(() => {
	  divElement.remove();
	}, 3000); // 10000 миллисекунд = 10 секунд
}

function create_loadbar() {
	//есть ли уже элемент на странице
	for (const child of document.body.children) {
		if (child.classList.contains('loadbar'))
			return false;
	}

	//добавить loadbar на страницу
    let loadbar = document.createElement('div');
    loadbar.classList.add('loadbar');

    //создаем элемент div для отображения прогресса загрузки
    let progressbar = document.createElement('div');
    progressbar.classList.add('loadbar_progress');
    let keyframes = [
      { transform: 'rotate(0deg)' },
      { transform: 'rotate(360deg)' }
    ];
    
    //создаем объект анимации
    let animation = progressbar.animate(keyframes, {
      duration: 1000,
      easing: 'linear',
      iterations: Infinity
    });
    //
    loadbar.appendChild(progressbar);//добавляем элемент progressbar в элемент loadbar
    document.body.appendChild(loadbar);//добавляем элемент loadbar в документ
    return true;
}

function remove_loadbar() {
	//убрать loadbar
    for (const child of document.body.children) {
		if (child.classList.contains('loadbar')) {
			document.body.removeChild(child);
			return true;
		}
	}
	return false;
}