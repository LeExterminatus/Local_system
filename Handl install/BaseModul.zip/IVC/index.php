<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT']."/IVC/coreX.php");
$E = new GUIGenerator();
?>