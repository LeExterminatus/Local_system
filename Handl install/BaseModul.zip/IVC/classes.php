<?php
class Chat extends GUIGenerator
{
	public function RequireModuls()
	{
		parent::RequireModuls();
		
	}
	public function MainGeneration()
	{
		
		
	}
}
?>