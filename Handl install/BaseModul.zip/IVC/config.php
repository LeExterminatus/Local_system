<?php
return array(
    'remembertime' => '180',
    'organizationname' => 'Электроагрегат'
);
?>