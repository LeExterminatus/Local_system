<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT']."/IVC/coreX.php");
require_once("classes.php");
$PageGenerator = new Inv_cntrl();
?>